package in.kassapos.a1broilers;

import android.media.MediaPlayer;


/**
 * Created by KASSAPOS8 on 9/18/2015.
 */
public class AppConstants {
    public static MediaPlayer ringtone;
    public static  Boolean isproductimagesshow=Boolean.TRUE;
}
