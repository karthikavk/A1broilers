package in.kassapos.a1broilers.myinterface;

import in.kassapos.a1broilers.api.Product;

/**
 * Created by KASSAPOS8 on 9/6/2015.
 */
public interface ProductSelected {
       void addProduct(Product product,int size);
}
