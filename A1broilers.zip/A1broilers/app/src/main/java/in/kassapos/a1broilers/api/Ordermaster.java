package in.kassapos.a1broilers.api;

public class Ordermaster{
	public Integer ordermasterid,orderstatus;
	public Float amount;
	public java.sql.Timestamp expected_date,created_date;
	public String companyid,name,userid,address1,address2,serviceareaid,city,landmark,created_by;    
}