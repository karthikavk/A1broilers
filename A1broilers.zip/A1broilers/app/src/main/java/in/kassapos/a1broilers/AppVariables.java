package in.kassapos.a1broilers;

import in.kassapos.a1broilers.api.OrderGroup;

/**
 * Created by KASSAPOS8 on 9/12/2015.
 */
public class AppVariables {
    public static OrderGroup orderGroup;
}
