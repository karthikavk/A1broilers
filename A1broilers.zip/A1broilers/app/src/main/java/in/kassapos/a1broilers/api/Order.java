package in.kassapos.a1broilers.api;

/**
 * Created by KASSAPOS8 on 9/6/2015.
 */
public class Order {
    public Product product;
    public Float quantity;
    public Integer cutsize;
}
