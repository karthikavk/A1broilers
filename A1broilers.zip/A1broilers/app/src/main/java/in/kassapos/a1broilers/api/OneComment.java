package in.kassapos.a1broilers.api;

public class OneComment {
	public boolean left;
	public String comment;

	public OneComment(boolean left, String comment) {
		super();
		this.left = left;
		this.comment = comment;
	}

}